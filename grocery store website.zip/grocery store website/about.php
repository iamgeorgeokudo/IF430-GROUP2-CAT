<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-image4.jpg" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>We offer high quality grocery products.</p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>We offer services 24/7.</p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/home-image.jpg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/glance2.webp" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>We are the best grocery providers in Eldoret at cheap and affordable prices.</p>
            <a href="#reviews" class="btn">clients reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/profile-2.jfif" alt="">
            <p>I was skeptical about ordering groceries online, but this website made it so easy! The products were high-quality and fresh, and the delivery was fast and convenient. I will definitely be using this service again!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Prote</h3>
        </div>

        <div class="box">
            <img src="images/profile-1.jfif" alt="">
            <p>I love the wide selection of products available on this website. I can find everything I need, from fresh produce to pantry staples, and the prices are very competitive. The customer service is also excellent, and any issues are resolved quickly.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Prince</h3>
        </div>

        <div class="box">
            <img src="images/profile-3.jpg" alt="">
            <p>I appreciate the sustainable practices of this e-grocery website. The packaging is compostable, and they partner with local farmers to support the community. Plus, the products are always fresh and high-quality. Highly recommend!</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Julies</h3>
        </div>

        <div class="box">
            <img src="images/profile-4.jpg" alt="">
            <p>I was impressed with the user-friendly design of this website. It was easy to find what I needed, and the checkout process was simple and secure. The delivery was also prompt and convenient, making my shopping experience hassle-free.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Praise </h3>
        </div>

        <div class="box">
            <img src="images/profile-5.jpg" alt="">
            <p>I have been using this e-grocery website for months now, and I am always impressed with the quality of the products and the customer service. The loyalty program is also a great incentive to keep shopping here. Highly recommend to anyone looking for a reliable and convenient grocery delivery service.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Malyna Lynn</h3>
        </div>

        <div class="box">
            <img src="images/profile-6.jpg" alt="">
            <p>I have tried a few different e-grocery websites, but this one stands out for its excellent prices and wide selection of products. The customer service is also top-notch, and any issues are resolved quickly. I have recommended this website to all my friends and family.</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Mercy May</h3>
        </div>

    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>